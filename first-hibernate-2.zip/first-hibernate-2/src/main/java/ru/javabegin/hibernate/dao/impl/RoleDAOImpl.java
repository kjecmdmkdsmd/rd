package ru.javabegin.hibernate.dao.impl;

import ru.javabegin.hibernate.dao.interfaces.objects.RoleDAO;

// реализация всех методов DAO
// не забывать - все роли сразу получаем с объектом User (fetch = EAGER) - специально так реализовали в классе User
// пока можем оставить пустым - если в будущем сюда будут добавлены методы (а можете просто удалить класс)
public class RoleDAOImpl implements RoleDAO {

}
